package com.klu.jfsd.exam;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientDemo {
    public static void main(String[] args) {
        // Create Configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Build SessionFactory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Open a Session
        Session session = sessionFactory.openSession();

        // Begin Transaction
        Transaction transaction = session.beginTransaction();

        try {
            // HQL Update with Positional Parameters
            String hql = "UPDATE Department SET name = ?1, location = ?2 WHERE id = ?3";
            int rowsAffected = session.createQuery(hql)
                    .setParameter(1, "Computer Science")
                    .setParameter(2, "Block A")
                    .setParameter(3, 1)
                    .executeUpdate();

            System.out.println("Rows Affected: " + rowsAffected);

            // Commit Transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
            sessionFactory.close();
        }
    }
}
